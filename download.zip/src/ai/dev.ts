import { config } from 'dotenv';
config();

import '@/ai/flows/tax-query-assistant.ts';